#!/bin/bash

if [ $1 -eq 5 ]
then
	echo " $1 is equal to 5"
else
	echo "$1 is not 5"
fi
